drop database db_estoque;
create database db_estoque;
use db_estoque;

create table Fabricante (
cod int auto_increment, 
nome varchar(70), 
cnpj varchar(15),
razaoSocial varchar(25),
primary key (cod));

create table Produto (
cod int auto_increment,
descr varchar(70),
quant int,
cod_fabricante int,
primary key (cod, cod_fabricante));

select * from Fabricante;

select * from Produto;

alter table Produto add foreign key (cod_fabricante) references Fabricante(cod);