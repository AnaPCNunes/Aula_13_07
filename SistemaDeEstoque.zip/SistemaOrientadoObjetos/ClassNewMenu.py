from ClasseCompra import *
from ClasseVenda import *
from ClassNewEstoque import NewEstoque

class Menu:
    def __init__(self):
        cadastro = NewEstoque()
        compra = Compra()
        venda = Venda()

        compra.entrada = cadastro
        venda.entrada = cadastro

        while True:
            entrada = input('\nEscolha a opção que deseja:\n'
                            '1 - Cadastrar Fabricantes\n'
                            '2 - Cadastrar Produtos\n'
                            '3 - Listar/Procurar Produtos\n'
                            '4 - Alterar Descrição do Produto\n'
                            '5 - Abastecimento de Estoque\n'
                            '6 - Retirada de Produto\n'
                            '7 - Histórico de entrada de Produtos\n'
                            '8 - Histórico de Saída de Produtos\n'
                            '9 - Deletar Produto do Sistema\n'
                            '10 - Deletar Fabricante do Sistema\n'
                            '0 - Sair\n')

            if entrada == '1':
                cod = None
                nome = input('Informe o nome do fabricante: ')
                cnpj = input('Informe o cnpj do fabricante: ')
                razaoSocial = input('Informe a razão social do fabricante: ')
                cadastro.cadastrar_fabricantes(cod, nome, cnpj, razaoSocial)

            elif entrada == '2':
                cod = None
                cod_fabricante = int(input('Informe o código do Fabricante: '))
                descr = input('Informe a descrição do produto: ')
                quant = 0
                cadastro.cadastrar_produtos(cod, descr, cod_fabricante, quant)

            elif entrada == '3':
                codig = int(input('Digite o código do produto que procura ou 0 para listar todos os produtos cadastrados: '))
                cadastro.listar_produtos(codig)

            elif entrada == '4':
                cod = input('Informe o código do produto: ')
                valor = input(('Informe a nova descrição: '))
                atributo = 'descr'
                cadastro.update_dados(atributo, valor, cod)

            #elif entrada == '5':


            #elif entrada == '6':
                #venda.vender()

           # elif entrada == '7':
                #compra.imprimir_abast()

            #elif entrada == '8':
                #enda.imprimir_retira()

            elif entrada == '9':
                cod = input('Informe o código do produto: ')
                cadastro.delete_prod(cod)

            elif entrada == '10':
                cod = input('Informe o código do Fabricante: ')
                cadastro.delete_fabri(cod)

            elif entrada == '0':
                break

            else:
                print('Opção Inexistente!')