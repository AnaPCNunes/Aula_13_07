from ClasseProduto import *
from ClasseFabricante import *

class Estoque:
    def __init__(self):
        self.listaProdutos = []
        self.listaFabricantes = []

    def cadastrar_fabricantes(self):
        codigoF = input('Informe o CÓDIGO do Fabricante: ')
        nomeF = input('Informe o NOME do Fabricante: ')
        cnpjF = input('Informe o CNPJ do Fabricante: ')
        razaoF = input('Informe a RAZÃO SOCIAL do Fabricante: ')
        self.listaFabricantes.append(Fabricante(codigoF, nomeF, cnpjF, razaoF))
        print('\nInformações cadastradas com sucesso!')

    def cadastrar_produtos(self):
        count = 0
        enCodF = input('\nInforme o código do fabricante do produto: ')
        for i in range(len(self.listaFabricantes)):
            if enCodF == self.listaFabricantes[i].cod:
                entradaCod = input('\nInforme o CÓDIGO do Produto: ')
                entradaDesc = input('Informe a DESCRIÇÃO do Produto: ')
                self.listaProdutos.append(Produto(entradaCod, entradaDesc, self.listaFabricantes[i]))
                print('\nInformações cadastradas com sucesso!')
            else:
                count += 1
                if count == len(self.listaFabricantes):
                    print('Não há fabricante cadastrado com este código!')

    def listar_produtos(self):
        count = 0
        entrada = input('\nPressione ENTER para listar TODOS ou digite o CÓDIGO para listar o produto desejado: ')
        for i in range(len(self.listaProdutos)):
            if entrada == self.listaProdutos[i].cod:
                print('Código:', self.listaProdutos[i].cod,
                      '- Descrição:', self.listaProdutos[i].desc,
                      '- Fabricante:', self.listaProdutos[i].fabri,
                      '- Quantidade:', self.listaProdutos[i].quant)
            elif entrada == '':
                print('Código:', self.listaProdutos[i].cod,
                      '- Descrição:', self.listaProdutos[i].desc,
                      '- Fabricante:', self.listaProdutos[i].fabri,
                      '- Quantidade:', self.listaProdutos[i].quant)
            else:
                count += 1
                if count == len(self.listaProdutos):
                    print('Não há produto cadastrado com este código!')

    def alterar_desc(self):
        count = 0
        entrada1 = input('\nInforme o código do produto:')
        for i in range(len(self.listaProdutos)):
            if entrada1 == self.listaProdutos[i].cod:
                self.listaProdutos[i].desc = input('Informe a NOVA DESCRIÇÃO: ')
            else:
                count += 1
                if count == len(self.listaProdutos):
                    print('Não há produto cadastrado com este código!')