import mysql.connector
from ClasseFabricante import *
from ClasseProduto import *


class NewEstoque:
    def __init__(self):
        self.conexao = mysql.connector.connect(
            host='localhost',
            user='root',
            password='q1w2e3',
            database='db_estoque')
        self.meu_cursor = self.conexao.cursor()

    def cadastrar_fabricantes(self, cod, nome, cnpj, razaoSocial):
        obj_fabri = Fabricante(cod, nome, cnpj, razaoSocial)
        comando_sql = f'insert into Fabricante (nome, cnpj, razaoSocial) value ("{obj_fabri.nome}", "{obj_fabri.cnpj}", "{obj_fabri.razaoSocial}")'
        self.meu_cursor.execute(comando_sql)
        self.conexao.commit()

    def cadastrar_produtos(self, cod, descr, cod_fabricante, quant):
        obj_prod = Produto(cod, descr, quant, cod_fabricante, )
        comando_sql = f'insert into Produto (descr, cod_fabricante, quant) value ("{obj_prod.descr}", {obj_prod.quant}, "{obj_prod.cod_fabricante}")'
        try:
            self.meu_cursor.execute(comando_sql)
            self.conexao.commit()
            print('\nCadastro feito com sucesso!')
        except:
            print('Não há fabricante cadastrado com este código!')

    def listar_produtos(self, codig):
        comando_sql = f'select Produto.cod, Produto.descr, Produto.quant, Fabricante.nome from Produto, Fabricante where Produto.cod = {codig} and Produto.cod_fabricante = Fabricante.cod'
        self.meu_cursor.execute(comando_sql)
        selecao = self.meu_cursor.fetchall()
        if selecao:
            for i in selecao:
                print(i)
        elif codig == 0:
            comando_sql = 'select Produto.cod, Produto.descr, Produto.quant, Fabricante.nome from Produto, Fabricante where Produto.cod_fabricante = Fabricante.cod'
            self.meu_cursor.execute(comando_sql)
            selecao = self.meu_cursor.fetchall()
            for i in selecao:
                print(i)
        else:
            print('Código não cadastrado!')

    def update_dados(self, atributo, valor, cod):
        comando_sql = f'update Produto set {atributo} = "{valor}" where cod = {cod}'
        self.meu_cursor.execute(comando_sql)
        self.conexao.commit()

    def delete_fabri(self, cod):
        comando_sql = f'delete from Fabricante where cod = {cod}'
        self.meu_cursor.execute(comando_sql)
        self.conexao.commit()

    def delete_prod(self, cod):
        comando_sql = f'delete from Produto where cod = {cod}'
        self.meu_cursor.execute(comando_sql)
        self.conexao.commit()
